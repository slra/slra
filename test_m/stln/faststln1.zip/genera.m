function[g]=genera(x,alpha,m,n)
% this function computes the generator matrix for $ M $
% input : the vectors $ x, \alpha $ and the dimensions $m,n$
% output $ g : $ the generator matrix wrt the block shift matrix.
%

%XM=K(m+2*n+1:2*m+2*n,1:m+n);
%XM=[XM(:,m+n),XM(:,1:m+n-1)],pause,
%AM=toeplitz(alpha(n:m+n-1),alpha(n:-1:1)); 



vz1=ones(m-1,1);vz2=ones(n-1,1);
VZ1=diag(vz1,-1);VZ2=diag(vz2,-1);VZ3=zeros(m,n);
%Z=[VZ1 VZ3;VZ3' VZ2];
%Z=diag(v,-1);
%M1=M-Z*M*Z';disp('****************'),M1,pause,
v=zeros(m+n,1);
x(n+1)=-1;
y=x/norm(x,2);
l=-1;
for i=n+1:-1:1,
  sum=0;
  l=l+1;
 % for j=i:-1:1,
 %   sum=sum+x(j+l)*y(j);
 % end
  v(l+1)=-x(i+l:-1:1+l)'*y(i:-1:1); 
 %v(l+1)=-sum;f
end
v(m+1:m+n)=alpha(n:-1:1);


xt=(v(1));
x1(1)=xt;
x2(1)=0;
for i=2:n+1,
    x1(i)=v(i);
    x2(i)=x1(i);
end
%
for i=m+1:m+n,
    x1(i)=-v(i)/xt;
    x2(i)=x1(i);
end
% x1 downdating
% x2 updating
%M1,-x1'*x1+x2'*x2,pause,
%M2=M1+x1'*x1-x2'*x2;rank(M2),pause,
%v1(1:m)=v(m:-1:1);
%v1(m+1:m+n)=alpha(m+n-1:-1:m);
v=zeros(m+n,1);
v(1:m)=alpha(n:m+n-1);%v1=v1';
v(1)=0;%=v-[0;v1(1:m+n-1)];
%v,pause,
xt=.5;
x3(m+1)=.5;
x4(m+1)=-.5;
for i=2:m+n,
  if i ~=m+1,
    x3(i)=v(i);
    x4(i)=x3(i);
  end
end
%x3 updating
%x4 dawndating
%disp('Vediamo ora'),pause,
%M2,x3'*x3-x4'*x4,pause,
%M3=M2-x3'*x3+x4'*x4,pause,
%norm(M3,2),pause
g=[x1;x2;x3;x4];
