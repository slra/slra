%Use:             yey(m)
%This function returns a square matrix
%of size mxm, with ones on the main
%anti-diagonal.
function [M]=yey(m)
t=zeros(m,m);
for i=1:m
  t(i,m-i+1)=1;
end
M=t;