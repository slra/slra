%***************************************************************************
%                                 HTLSU.M
%***************************************************************************
% PURPOSE:  Estimation algorithm with TLS solution in U space for the 
%           nonlinear parameters and LS solution for the linear parameters.
%***************************************************************************
% CALL:     [freq,damp,ampl,phas]=htlsU(vhtls1,vhtls2,Kest,fsampl,t,M)
%***************************************************************************
% INPUT:    vhtls1 -- chosen data vector for the 1st system of HTLS algorithm
%           vhtls2 -- chosen data vector for the 2nd system of HTLS algorithm
%           Kest   -- estimated number of damped exponentials (model order)
%           fsampl -- sample frequency          
%           t      -- sampled time sequence for vhtls
%           M      -- number of matrix columns
% OUTPUT:   freq   -- estimated frequency      row vector
%           damp   -- estimated damping factor row vector
%           ampl   -- estimated amplitude      row vector
%           phas   -- estimated phase          row vector
%***************************************************************************

function [freq,damp,ampl,phas]=htlsu(vhtls1,vhtls2,Kest,fsampl,t,M)

%-----------------------------initialization--------------------------------
N=length(vhtls1);
L=N+1-M;
vhtls1=vhtls1(:);
fast=1;
if fast==0
  colhmat=vhtls1(1:L);
  rowhmat=vhtls1(L:N);
  hmat=hankel(colhmat,rowhmat);
  [u,s,v]=svd(hmat,0);
  %-----------------------truncation to the given order-----------------------
  up=u(:,1:Kest);
  s1=s(1:Kest,1:Kest);
  v1=v(:,1:Kest);
else 
   %keyboard
   sig=vhtls1;
   nc=Kest;
   save /users/sista/lemmerli/ARPACK/EXAMPLES/SVD/htlsu2fd sig nc -v4
   !/users/sista/lemmerli/ARPACK/EXAMPLES/SVD/dsvdv2
   load /users/sista/lemmerli/ARPACK/EXAMPLES/SVD/singvect
   up=sv;
 end
 %keyboard

%------------------- TLS solution for the 1st system------------------------
%up=u1*s1^.5;
%up=u1;
upt=up(1:L-1,:);           % top part of matrix [up] without bottum line
upb=up(2:L,:);             % bottom part of matrix [up] without top line
cas=upt;
cas(:,Kest+1:2*Kest)=upb;  % cascade matrix [upt upb] of (L-1) by 2*Kest
[u,s,v]=svd(cas,0);   
q=-v(1:Kest,Kest+1:2*Kest)*pinv(v(Kest+1:2*Kest,Kest+1:2*Kest)); % TLS sol.
z=eig(q).';               
[s, I]=sort(imag(log(z))); % arranges the frequencies in ascending order
z=z(I);
a=fsampl/(2*pi);
for i=1:Kest
    freq(i)=imag(log(z(i)))*a;
    damp(i)=-real(log(z(i))*fsampl);
 end
%-------------------LS solution for the 2nd system--------------------------
[ampl,phas]=linpara(vhtls2,Kest,freq,damp,t);

